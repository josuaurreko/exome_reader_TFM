if(!(require(devtools))) {install.packages('devtools')}
if(!(require(DT))) {devtools::install_github('rstudio/DT')}
if(!(require(vcfR))) {install.packages('vcfR')}
if(!(require(dplyr))) {install.packages('dplyr')}
if(!(require(tidyr))) {install.packages('tidyr')}
if(!(require(splitstackshape))) {install.packages('splitstackshape')}
if(!(require(data.table))) {install.packages('data.table')}
if(!(require(shiny))) {install.packages('shiny')}
if(!(require(shinythemes))) {install.packages('shinythemes')}
if(!(require(shinydashboard))) {install.packages('shinydashboard')}

source("helpers.R")

### PLANES FUTUROS:

# Revisar porque acepta archivos que no son en los input: 
# La función no permite hacerlo, tendrían que checkearse en la misma lectuar VCF

# Define UI for application that draws a histogram
ui <- fluidPage(theme = shinytheme("sandstone"),

    # Application title
    titlePanel("Lector de VCF"),
    dashboardHeader(title = "", tags$li(class = "dropdown",tags$img(src = "uoc.png", height = 75, width = 150, align = "right")), 
                    tags$li(class = "dropdown", actionLink("man",h3("Manual de usuario"))),
                    tags$li(class = "dropdown", actionLink("man_var",h3("Descripción de columnas")))),

    # Sidebar with a slider input for number of bins
    navbarPage("Barra de navegación",
        tabPanel("Aplicación",
        sidebarLayout(
            sidebarPanel(
                HTML(paste("<strong><h2>Archivos</h2></strong><br>")),
                fileInput("vcf1",label = "Archivo a consultar", accept = c(".vcf.gz",".vcf")),
                fileInput("vcf2",label = "Archivo a comparar", accept = c(".vcf.gz",".vcf")),
                helpText("Clickar aquí antes de intentar filtrar."),
                actionButton("view", "Ver variantes del caso y reiniciar filtros"), 
                HTML(paste("<strong><h2>Comparación de VCF</h2></strong><br>")),
                radioButtons("intersect_vcf","Método de comparación",choices = list("Posición exacta"=1,"Gen común"=2)),
                #checkboxInput("intersect_vcf", "¿Comparar 2 VCF?", value = TRUE),
                actionButton("cruzar_vcf", "Comparar VCF"),
                HTML(paste("<strong><h2>Filtros</h2></strong><br>")),
                uiOutput("caracteristica"), 
                uiOutput("eleccion"),
                uiOutput("comparador"),
                actionButton("filtrar", "Aplicar un filtro"),
            ),
      
            # Show a plot of the generated distribution
            mainPanel(
               h2("Resultados"),
               uiOutput("errores"),
               tags$head(tags$style("#errores{color: red;font-size: 20px;}")),
               tags$head(tags$style(type="text/css", "
                 #loadmessage {
                   position: fixed;
                   top: 0px;
                   right: 0px;
                   width: 50%;
                   padding: 5px 0px 5px 0px;
                   text-align: center;
                   font-weight: bold;
                   font-size: 100%;
                   color: #000000;
                   background-color: #CCFF66;
                   z-index: 105;
                 }
              ")),
               conditionalPanel(condition="$('html').hasClass('shiny-busy')",
                                tags$div("Cargando...",id="loadmessage")),
               verbatimTextOutput("N_variantes"),
               DT::dataTableOutput("show_variants"),
            )
        )
      ), tabPanel("Filtros y Descargas", 
                 verbatimTextOutput("filter_summary"),
                 downloadButton("download1", "Descargar tabla actual"),
                 downloadButton("download2", "Descargar filtros en texto")
      ), tabPanel("Panel virtual",
                 HTML(paste("<h2>Genera aquí tu panel virtual</h2><br>")),
                 HTML(paste("<p>Se trata de otro filtro más</p><p>Sube un archivo .txt con el nombre HGVS de un gen en cada linea. Ejemplo:</p>")),
                 downloadButton("panel_example","Ejemplo"),
                 p(""),
                 fileInput("panel",label = "Listado de genes", accept = c(".txt")),
                 actionButton("generate_panel", "Generar panel"),
                 uiOutput("errores2"),
                 tags$head(tags$style("#errores2{color: red; font-size: 20px;}")),
               )
))

# Define server logic required to draw a histogram
server <- function(input, output, session) {
  options(shiny.maxRequestSize=200*1024^2)  # Aumenta el tamaño maximo de file
  
  # reactive input
  variantes1 <- reactive({
    if(is.null(input$vcf1))
      return()
    vcf_read_table(input$vcf1$datapath)
  })
  variantes2 <- reactive({
    if(is.null(input$vcf2))
      return()
    vcf_read_table(input$vcf2$datapath)
  })
  
  # Filtros de UI
  # Primer filtro general
  
  output$caracteristica<-renderUI({
    if(is.null(variantes1))
      return()
    else(selectInput("columna","Elige una caracteristica",
                     choices = colnames(variantes1()),
                     selected = colnames(variantes1())[1]
                     )
    )
  })
  
  # Segundo filtro actualizable dependiendo el primero. Los condicionales cubren los 3 tipos de datos input.
  
  output$eleccion <- renderUI({
    filtro <- req(input$columna) # req() es OBLIGATORIO, sino, intenta buscar valores que no existen y se vuelve idiota
    if(is.numeric(variantes1()[[filtro]])){
      numericInput("numinput",label=paste("Filtro de ", filtro),
                         value = round(mean(variantes1()[[filtro]], na.rm = TRUE),3),
                         min = min(variantes1()[[filtro]], na.rm = TRUE),
                         max= max(variantes1()[[filtro]], na.rm = TRUE),
                         step = max(variantes1()[[filtro]])/100)
    } else if (is.factor(variantes1()[[filtro]])) {
      selectInput("facinput",label=paste0("Filtro de ", filtro),
                        choices=unique(variantes1()[[filtro]]), multiple = TRUE)
    } else if (is.character(variantes1()[[filtro]])) {
      textInput("charinput",label=paste0("Filtro de ", filtro),placeholder = "Busqueda por texto")
    }
  })
  
  output$comparador <- renderUI({
    filtro <- req(input$columna) 
    if(is.numeric(variantes1()[[filtro]]) && is.numeric(input$numinput)) {
      selectInput("operador", label = "Mayor o menor", choices=list(">"=">","<","<"))
    }
  })

  # Aquí pongo los reactiveValues. Los elementos dinámicos del dataframe que se mostrara.
  
  intersect_checkbox <- reactive({"¿Son variantes comunes de dos VCF?    NO \n"})
  user_filters <- reactiveValues(texto_filtros = NULL)
  output$filter_summary <- renderText(user_filters$texto_filtros)
  
  variantes_filtradas <- reactiveValues(datos = NULL)
  
  # Simple output. Ver el VCF cargado. Las variantes deben inicializarse en un reactiveValues.
  # Como está vacío al empezar, da errores. Si lo hago dentro de un boton, funciona bien
  
  observeEvent(input$view, {
    if (is.null(variantes1())) {output$errores <- renderUI({renderText('Error: Sube un VCF en archivo a consultar')})
    } else {output$errores <- renderUI({renderText('')})}
    variantes_filtradas$datos <- variantes1()
    user_filters$texto_filtros <- intersect_checkbox()
    
    output$N_variantes <- renderText({
      paste0('Tenemos un total de ',nrow(variantes1()),' variantes en el archivo annovar')
    })
    
    output$show_variants <- DT::renderDataTable({
      DT::datatable(variantes1(), options = list(
      autoWidth = TRUE,
      columnDefs = list(list(width = '20px', targets = "_all")),
      fixedColumns = list(leftColumns = 2)
      ), extensions = 'FixedColumns')
    })
  })
  
  # Intersect VCF
  
  observeEvent(input$cruzar_vcf, { 
    
    if (is.null(variantes2())) {
      output$errores <- renderUI({renderText('Error: No has subido ningún VCF para comparar')})
      variantes_intersect <- reactive({})
    } else if (input$intersect_vcf == 1) {
      common <- dplyr::intersect(variantes1()$ChromKey, variantes2()$ChromKey)
      variantes_intersect <- reactive({subset(variantes1(), ChromKey %in% common) })
      output$errores <- renderUI({renderText('')})
    } else if (input$intersect_vcf == 2) {
      common <- dplyr::intersect(variantes1()$Gene.refGene, variantes2()$Gene.refGene)
      variantes_intersect <- reactive({
        rbind(subset(variantes1(), Gene.refGene %in% common),subset(variantes2(), Gene.refGene %in% common)) })
      output$errores <- renderUI({renderText('')})
    } 
    
    # Mostrar resultado filtrado
    
    output$N_variantes <- renderText({
      paste0('Tenemos un total de ',nrow(variantes_intersect()),' variantes en el archivo annovar')
    })
    output$show_variants <- DT::renderDataTable({
      DT::datatable(variantes_intersect(), options = list(
        autoWidth = TRUE,
        columnDefs = list(list(width = '20px', targets = "_all")),
        fixedColumns = list(leftColumns = 2)
      ), extensions = 'FixedColumns')
    })
    variantes_filtradas$datos <- variantes_intersect()
    
    # Arreglando el string de información de filtros
    
    texto <- user_filters$texto_filtros
    texto <-  if ((input$intersect_vcf == 1 || input$intersect_vcf == 2) && !is.null(variantes2())) {
      gsub("\\¿Son variantes comunes de dos VCF\\?    NO \n","¿Son variantes comunes de dos VCF?    SI \n",texto)
      } else {"¿Son variantes comunes de dos VCF?    NO \n"}
    user_filters$texto_filtros <- texto
    })

  # Filtros. necesitas req() para que caze los input. aparte, la función subset no permite un character al seleccionar columna.
  # Se necesita get(). Por otro lado no se hacer que el mayor o menor sea un input.
  
  observeEvent(input$filtrar, {
    if (is.null(variantes_filtradas$datos)) {
    output$errores <- renderUI({renderText('Error: Primero haz click en ver variantes')})} else {
    vfil <- as.data.frame(variantes_filtradas$datos)
    texto <- user_filters$texto_filtros
    val_col <- input$columna
    
    if (is.numeric(vfil[[val_col]])){ 
      val_num <- req(input$numinput)
      # val_col %in% c("QUAL","gt_DP","pLi.refGene","phyloP100way_vertebrate","GERP++_NR","GERP++_RS")
      if (input$operador == ">"){
        df <- subset(vfil, get(val_col) >= val_num | is.na(get(val_col)))
        #val_col %in% c("gnomAD_exome_ALL","gnomAD_exome_NFE","gnomAD_genome_ALL","gnomAD_genome_NFE")
      } else if (input$operador == "<") {
        df <- subset(vfil, get(val_col) <= val_num | is.na(get(val_col)))
      }
      texto <- paste0(texto, "Has usado el filtro numérico ",val_col, " con valor ", input$operador," ", val_num, "\n")
    } else if (is.factor(vfil[[val_col]])) {
      val_fac <- c(unlist(req(input$facinput)))
      df <- subset(vfil, get(val_col) %in% val_fac)
      texto <- paste0(texto, "Has usado el filtro categórico ",val_col, " con valor ", paste(val_fac, collapse = ' '), "\n")
    } else if (is.character(vfil[[val_col]])) {
      val_char <- req(input$charinput)
      df <- subset(vfil, get(val_col) == val_char)
      texto <- paste0(texto, "Has usado el filtro por palabra ",val_col, " con valor ", val_char, "\n")
    }
   
    output$errores <- renderUI({renderText('')})
    output$N_variantes <- renderText({
      paste0('Tenemos un total de ',nrow(df),' variantes en el archivo annovar')
    })
    output$show_variants <- DT::renderDataTable({
      DT::datatable({df}, options = list(
        autoWidth = TRUE,
        columnDefs = list(list(width = '20px', targets = "_all")),
        fixedColumns = list(leftColumns = 2)
      ), extensions = 'FixedColumns')
    })
    user_filters$texto_filtros <- texto
    variantes_filtradas$datos <- df
    }
  })
  
  output$download1 <- downloadHandler(
    filename = function() {
      paste(unique(as.data.frame(variantes_filtradas$datos$Indiv[1])),"_variantes_", Sys.Date(), ".csv", sep="")
    },
    content = function(file) {
      write.csv(as.data.frame(variantes_filtradas$datos), file)
    }
  )
  output$download2 <- downloadHandler(
    filename = function() {
      paste(unique(as.data.frame(variantes_filtradas$datos$Indiv[1])),"_filtros_", Sys.Date(), ".txt", sep="")
    },
    content = function(file) {
      write.table(user_filters$texto_filtros, file, sep = "\n")
    }
  )
  
  # Manuales de usuario y de variantes
  
  user_manual <- modalDialog(
    title = "Manual del usuario",
    HTML(paste(
         "<br/> 1) Cargar el archivo vcf o vcf.gz del paciente que deseas consultar. A partir de 10000 variantes es lento, y un exoma completo lleva varios minutos. En mi PC con 64 GB de RAM, 2 minutos",
               "2) Cargar el archivo vcf o vcf.gz del paciente contra el que deseas comparar el primer archivo.",
               "3) Clica en ver variantes y reiniciar filtros. Cada vez que debas borrar filtros o empezar de nuevo, vuelve a clickar aqui.",
               "4) Marca como quieres realizar la comparación de pacientes: por posición exacta o por gen. Ten en cuenta que esto es un filtro.",
               "5) Clica en comparar si deseas continuar con las variantes comunes de ambos pacientes. Si solo deseas filtrar al paciente principal, ignora ese botón.",
               "6) Si te interesa hacer un panel virtual, en la pestaña con ese nombre debes subir un listado de genes como en el ejemplo y clickar en generar filtro. Se trata de otro filtro realmente.",
               "7) Filtros: Las columnas del dataframe son los filtros. Elige aquella con la que quieras filtrar.",
               "8) Hay filtros numéricos, categóricos y textuales. El programa los detecta automáticamente.",
               "8) Cada vez que aplicas un filtro se guarda un mensaje informativo en la pestaña 'filtros utilizados', recuerda consultarla.",
               "9) Después de aplicar un filtro con el boton 'aplicar un filtro', verás tus resultados. Se pueden aplicar más filtros en cascada. Repite los pasos 6-8 para ello.",
               "10) Cuando termines de filtrar (o si introdujiste mal un filtro) pulsa ver variantes y reiniciar filtros para volver a empezar. Esto elimina las comparaciones de VCF, el panel virtual y los filtros",
               "11) Si deseas cargar archivos distintos no necesitas reiniciar la aplicación. Simplemente sube uno nuevo",
               sep="<br/><br/>")),
    easyClose = TRUE,
    footer = tagList(
      modalButton("Close")
    )
  )
  var_manual <- modalDialog(
    title = "Manual del columnas",
    HTML(paste("<br/><br/>
               <strong> 1) ChromKey: </strong> Campo artificial que consta de cromosoma:posición. Util para cruzar VCF.",
              "<strong> 2) POS: </strong> Posición genómica.",
              "<strong> 3) CHROM: </strong> Cromosoma.",
              "<strong> 4) ID: </strong> rs identificador de la variante.",
              "<strong> 5) REF: </strong> Alelo de referencia.",
              "<strong> 6) ALT: </strong> Alelo alternativo, la variante.",
              "<strong> 7) QUAL: </strong> Indicador de calidad del variant calling.",
              "<strong> 8) FILTER: </strong> En caso de hacer filtros con GATK, PASS indica que se han pasado.",
              "<strong> 9) gt_DP: </strong> Profundidad de lectura ",
              "<strong> 10) gt_AD: </strong> Cuantas lecturas hay en el alelo de referencia y el alternativo.",
              "<strong> 11) gt_GT: </strong> Genotipo. 0 = wild type, 1 = variante.",
              "<strong> 12) Func.refGene: </strong> Posición que ocupa la variante en el gen: exónica, intrónica, UTR...",
              "<strong> 13) Gene.refGene: </strong> Nombre del gen.",
              "<strong> 14) GeneDetail.refGene: </strong> Nombre formal de la variante con accesion ID.",
              "<strong> 15) ExonicFunc.refGene: </strong> Efecto del cambio: variante sinónima, no sinónima, stop...",
              "<strong> 16) AAChange.refGene: </strong> Cambio de aminoácido.",
              "<strong> 17) pLi.refGene: </strong> Valor pLi (0-1). Cuanto más cercano a 1, mas probable es que alterar ese gen sea patogénico.",
              "<strong> 18) CLNSIG: </strong> Significado de la variante según clinvar.",
              "<strong> 29) SIFT_Pred: </strong> Predictor SIFT. T = Tolerated D = Damaging",
              "<strong> 20) SIFT4G_Pred: </strong> Predictor SIFT4G. T = Tolerated D = Damaging",
              "<strong> 21) MetaLR_Pred: </strong> Predictor MetaLR T = Tolerated D = Damaging",
              "<strong> 22) GERP++_NR: </strong> Predictor conservación posición (-12.3, 6.18) de menos a más conservado.",
              "<strong> 23) GERP++_RS: </strong> Valor RS del GERP score. Significa rejected substitutions.",
              "<strong> 24) PhyloP100way_vertebrate: </strong> Predictor de conservación. Valores positivos indican conservación y negativos zona cambiante.",
              "<strong> 25) GnomAD_exome_ALL: </strong> Frecuencia poblacional general en exoma de GnomAD.",
              "<strong> 26) GnomAD_exome_NFE: </strong> Frecuencia poblacional europeo no finlandes en exoma de GnomAD.",
              "<strong> 27) GnomAD_genome_ALL: </strong> Frecuencia poblacional general en genoma de GnomAD.",
              "<strong> 28) GnomAD_genome_NFE: </strong> Frecuencia poblacional europeo no finlandes en exoma de GnomAD.",
               sep="<br/>")),
    easyClose = TRUE,
    footer = tagList(
      modalButton("Close")
    )
  )

  # Mostrar instrucciones
  
  observeEvent(input$man,{
    showModal(user_manual)
  })
  observeEvent(input$man_var,{
    showModal(var_manual)
  })
  
  # Panel virtual
  
  # Ejemplo descargable
  example_r <- data.frame(ejemplo = c("PKD","EGFR","HIF1A"))
  output$panel_example <- downloadHandler(
    filename = function() {"ejemplo.txt"},
    content = function(file) {write.table(example_r, file, sep = "\n", row.names = FALSE, col.names = FALSE, quote = FALSE)}
    )
  
  # Filtro de panel virtual
  observeEvent(input$generate_panel, {
    if (is.null(variantes_filtradas$datos)) {
    output$errores2 <- renderUI({renderText('Error: Primero sube el VCF en la pestaña principal y haz click en ver variantes.')})
    } else if (is.null(input$panel)) {
    output$errores2 <- renderUI({renderText('Error: Sube un listado de genes.')})
    } else {output$errores2 <- renderUI({renderText('')})
    vfil <- as.data.frame(variantes_filtradas$datos)
    texto <- user_filters$texto_filtros
    
    # El filtro
    #val_panel_react <- reactive({if (is.null(input$file)) {return("")}
      #read.table(input$panel)})
    val_panel <- read.table(req(input$panel$datapath))
    val_panel <- c(val_panel[,1])
    head(val_panel)
    df <- subset(vfil, Gene.refGene %in% val_panel)
    texto <- paste0(texto, "Has generado un panel virtual con ", paste(length(val_panel), collapse = ' '), " genes", "\n")
    
    # Y repetir el output
    output$N_variantes <- renderText({
      paste0('Tenemos un total de ',nrow(df),' variantes en el archivo annovar')
    })
    output$show_variants <- DT::renderDataTable({
      DT::datatable({df}, options = list(
        autoWidth = TRUE,
        columnDefs = list(list(width = '20px', targets = "_all")),
        fixedColumns = list(leftColumns = 2)
      ), extensions = 'FixedColumns')
    })
    user_filters$texto_filtros <- texto
    variantes_filtradas$datos <- df
    }
  })
  
}

# Run the application 
shinyApp(ui = ui, server = server)
