vcf_read_table <- function(vcfdir, type="annovar") {
  if (type == "jannovar") {
    myvcf <- read.vcfR(vcfdir)
    
    # Extrae los campos de interes del objeto S4 a una tibble de tidyverse.
    vcf_dataframe <- vcfR2tidy(myvcf, verbose = FALSE)
    meta_info <- vcf_dataframe$meta
    final_dataframe <- merge(vcf_dataframe$fix, vcf_dataframe$gt) # Aqui con un VCF demasiado grande, muere.
    final_dataframe <- cSplit(final_dataframe, splitCols = 'ANN', sep="|")
    final_dataframe$ChromKey <- paste(final_dataframe$CHROM,":",final_dataframe$POS, sep = "")
    # Este ultimo arreglillo es para permitir el intersect
    
    # Los nombres de las anotaciones ANN. Los campos ANN no se procesan bien, aquñi lo arreglo.
    anotaciones <- filter(meta_info, ID == 'ANN')[5]
    anotaciones <- gsub('Functional annotations:','',anotaciones)
    anotaciones <- gsub("\\'",'',anotaciones)
    anotaciones <- cSplit(data.frame('description' = anotaciones), 'description','|')
    anotaciones <- as.character(anotaciones[1,])
    
    # Los nombres de columnas a sustituir.
    colsubs <- grep('^ANN.*$',names(final_dataframe))
    colnames(final_dataframe)[c(colsubs)] <- anotaciones
    
    # resultado
    print("Procesado")
    return (final_dataframe)
  }
  else if (type == "annovar") {
    myvcf <- read.vcfR(vcfdir)
    samples = ncol(myvcf@gt)-1
    print(paste("En este VCF hay",samples,"muestras"))
    myvcf <- vcfR2tidy(myvcf, verbose = FALSE)
    myvcf <- merge(myvcf$fix, myvcf$gt)
    col_list <- c("ChromKey","Indiv","POS","CHROM","ID","REF","ALT","QUAL","FILTER","gt_DP","gt_AD","gt_GT",
                  "Func.refGene","Gene.refGene","GeneDetail.refGene","ExonicFunc.refGene","AAChange.refGene","pLi.refGene","CLNSIG",
                  "SIFT_pred","SIFT4G_pred","MetaLR_pred","GERP++_NR","GERP++_RS","phyloP100way_vertebrate",
                  "gnomAD_exome_ALL","gnomAD_exome_NFE","gnomAD_genome_ALL","gnomAD_genome_NFE")
    myvcf <- select(myvcf, all_of(col_list))
    myvcf[,c(4,9,12,13,16,19,20,21,22)] <- lapply(myvcf[,c(4,9,12,13,16,19,20,21,22)], as.factor)
    myvcf[,c(18,23,24,25)] <- lapply(myvcf[,c(18,23,24,25)], as.numeric)
    myvcf <- filter(myvcf, !is.na(myvcf$gt_GT))
    myvcf$pLi.refGene <- round(myvcf$pLi.refGene, 4)
    myvcf$POS <- as.character(myvcf$POS)
    myvcf$ChromKey <- paste(myvcf$CHROM, myvcf$POS, sep = ":")
    print("Procesado")
    return(myvcf)
  }
  else {
    print("Error, introduce 'jannovar o annovar' como type =")
  }
}
