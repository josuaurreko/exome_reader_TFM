#!/bin/bash

if [ "$1" == "-h" ] || [ "$1" == "--help" ] ; then
    echo "Como primer argumento añade el .bed y como segundo argumento, un vcf o vcf.gz"
    echo "El archivo .bed lo puedes obtener metiendo una lista de genes en un .txt al UCSC Table browser"
    echo "UCSC Table Browser: https://genome.ucsc.edu/cgi-bin/hgTables"
    echo "Convenientemente, la ruta de la terminal y los archivos deberían estar en la misma carpeta"
    exit 0
fi

# Si se desea anonimizar bcftools reheader -s 'nombres.txt' a70003.vcf.gz | bcftools view -Oz > paciente2.vcf.gz

# Primero alterar el nombre para el output
paciente="$1"
paciente=${paciente%".vcf.gz"}

# Generar un panel virtual solo requiere tabix y bcftools
tabix $1
bcftools view -Oz -R $2 -o $paciente'.panel.vcf.gz' $1
